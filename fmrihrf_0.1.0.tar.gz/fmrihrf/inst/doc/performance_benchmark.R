## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7,
  fig.height = 5
)

## ----setup--------------------------------------------------------------------
library(fmrihrf)
library(microbenchmark)

## ----generate-events----------------------------------------------------------
# Generate random event times
set.seed(123)
n_trials <- 2000
total_time <- 600  # 10 minutes
onsets <- sort(runif(n_trials, min = 0, max = total_time - 20))

# Time grid
dt <- 1.0
time_grid <- seq(0, total_time, by = dt)

## ----fmrihrf-benchmark--------------------------------------------------------
# Create FIR HRF
fir_hrf <- HRF_FIR

# Benchmark fmrihrf
fmrihrf_time <- microbenchmark(
  fmrihrf = {
    reg <- regressor(
      onsets = onsets,
      hrf = fir_hrf,
      duration = 0,
      amplitude = 1
    )
    design_matrix <- evaluate(reg, time_grid)
  },
  times = 10
)

print(fmrihrf_time)

## ----base-r-benchmark---------------------------------------------------------
# Base R implementation
create_fir_design_base <- function(onsets, time_grid, n_basis = 20) {
  n_time <- length(time_grid)
  design <- matrix(0, n_time, n_basis)
  
  for (i in seq_along(onsets)) {
    onset_idx <- which.min(abs(time_grid - onsets[i]))
    for (j in 1:n_basis) {
      idx <- onset_idx + j - 1
      if (idx <= n_time) {
        design[idx, j] <- design[idx, j] + 1
      }
    }
  }
  design
}

# Benchmark base R
base_r_time <- microbenchmark(
  base_r = {
    design_matrix <- create_fir_design_base(onsets, time_grid)
  },
  times = 10
)

print(base_r_time)

## ----results-summary----------------------------------------------------------
# Calculate speedup
fmrihrf_median <- median(fmrihrf_time$time) / 1e6  # Convert to milliseconds
base_r_median <- median(base_r_time$time) / 1e6

speedup <- base_r_median / fmrihrf_median

cat(sprintf("fmrihrf median time: %.2f ms\n", fmrihrf_median))
cat(sprintf("Base R median time: %.2f ms\n", base_r_median))
cat(sprintf("Speedup factor: %.1fx\n", speedup))

## ----scaling-test, fig.cap="Performance scaling with number of events"--------
n_events_vec <- c(100, 500, 1000, 2000, 5000)
times_fmrihrf <- numeric(length(n_events_vec))
times_base <- numeric(length(n_events_vec))

for (i in seq_along(n_events_vec)) {
  n <- n_events_vec[i]
  test_onsets <- sort(runif(n, min = 0, max = total_time - 20))
  
  # Time fmrihrf
  t1 <- microbenchmark(
    {
      reg <- regressor(onsets = test_onsets, hrf = fir_hrf)
      evaluate(reg, time_grid)
    },
    times = 5
  )
  times_fmrihrf[i] <- median(t1$time) / 1e6
  
  # Time base R
  t2 <- microbenchmark(
    create_fir_design_base(test_onsets, time_grid),
    times = 5
  )
  times_base[i] <- median(t2$time) / 1e6
}

# Plot results
plot(n_events_vec, times_base, type = "b", pch = 19, col = "red",
     xlab = "Number of Events", ylab = "Time (ms)",
     main = "Performance Scaling Comparison",
     ylim = c(0, max(times_base) * 1.1))
lines(n_events_vec, times_fmrihrf, type = "b", pch = 19, col = "blue")
legend("topleft", legend = c("Base R", "fmrihrf"), 
       col = c("red", "blue"), lty = 1, pch = 19)

